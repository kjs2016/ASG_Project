from cx_Freeze import setup, Executable

# 실행 파일로 변환할 스크립트 파일명
script = 'main.py'

# 실행 파일에 대한 정보 설정
exe = Executable(
    script,
    base=None,  # GUI 애플리케이션인 경우 None으로 설정
    targetName='ANS.exe',  # 생성될 실행 파일명
)

# 실행 파일 빌드 설정
build_exe_options = {
    'packages': [],  # 필요한 패키지 추가
    'includes': [],  # 필요한 모듈 추가
    'excludes': [],  # 제외할 모듈 설정
    'include_files': [
        ('굿모닝충청.py', '금강일보.py'),  # 모듈 파일 추가
        ('내일신문.py', '농수축산신문.py'),
        ('뉴스세상.py', '뉴스충청인.py'),
        ('뉴스타운.py', '대전일보.py'),  
        ('대전투데이.py', '동양일보.py'), 
        ('디트뉴스.py', '로컬투데이.py'),
        ('배방신문.py', '백제뉴스.py'),
        ('아산뉴스.py', '아산데스크.py'),
        ('아산데일리.py', '아산미래신문.py'),
        ('아산시사신문.py', '아산투데이.py'),
        ('엑셀모듈.py', '온아신문.py'),
        ('온양신문.py', '온주신문.py'),
        ('중부매일.py', '중앙매일.py'),
        ('천지일보.py', '충남신문.py'),
        ('충남일보.py', '충남타임즈.py'),
        ('충남in.py', '충청뉴스.py'),
        ('충청매일.py', '아산시시설관리공단_사진.png'),
        ('바탕화면.PNG', 'pdf_save.PNG'),
        ('프린트모듈.py', 'C뉴스041.py'),
        ('IPTV뉴스.py', '백제뉴스.py'),
        ('print.PNG', 'Log.txt')

    ],
}

# 실행 파일 빌드 설정과 실행 파일 목록을 사용하여 빌드 설정 생성
options = {
    'build_exe': build_exe_options,
    'executables': [exe],
}

# 실행 파일 빌드
setup(options=options)