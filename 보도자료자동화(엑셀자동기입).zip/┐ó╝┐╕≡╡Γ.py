import openpyxl as op

def excel_start(date_n, team_n, file_n, news_alphabet_list):
    date_val = date_n
    team_val = team_n
    file_val = file_n
    news_alphabet = news_alphabet_list

    #파일 경로 지정
    path = r"C:/Users/User/Desktop/7. 2023년 보도기사 스크랩"
    filename = "0. 2023년 보도실적.xlsx"
    file_path = path + "/" + filename

    """
    # 워크북 열기
    wb = op.load_workbook(file_path)

    #활성화된 시트 선택
    ws = wb.active

    #셀에 값 입력
    #ws.cell(row=53, column=2).value = "입력테스트1"

    a = "F"
    b = "53"
    c = "G"
    d = "53"

    ws[a+b].value = 1
    ws[c+d].value = 1

    # 파일 저장
    wb.save(file_path)
    """
    #파일 경로 지정
    sheet_name = "보도실적"
    column = "B"  # 값을 확인할 열의 알파벳 표기

    # 워크북 열기
    wb = op.load_workbook(file_path)

    # 시트 선택
    ws = wb[sheet_name]

    # 마지막 행 확인
    last_row = ws.max_row

    # 값을 확인할 열의 범위 지정
    column_range = ws[column]

    # 마지막 행까지 반복하며 값이 있는 마지막 행 찾기
    last_row_with_value = None
    for cell in column_range:
        if cell.value:
            last_row_with_value = cell.row

    print("B열의 값이 들어있는 마지막 행:", last_row_with_value)

    ws = wb.active

    #data1 = ws.cell(row=last_row_with_value, column=4).value
    #print("D52번째 값 : "+data1)

    column_value = str(last_row_with_value+1)

    ws["B"+column_value] = date_val
    ws["C"+column_value] = team_val
    ws["D"+column_value] = file_val

    print(news_alphabet)

    for i in range(len(news_alphabet)):
       ws[news_alphabet[i]+column_value].value = 1

    #파일 저장
    wb.save(file_path)
